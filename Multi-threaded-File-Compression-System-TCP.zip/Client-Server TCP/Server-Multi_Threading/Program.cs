﻿using System;
using System.IO;
using System.IO.Compression;
using System.Net;
using System.Net.Sockets;
using System.Threading;

namespace ServerMultiThreading
{
    class Program
    {
        static Socket server;

        static void Main(string[] args)
        {
            server = new Socket(
                AddressFamily.InterNetwork,
                SocketType.Stream,
                ProtocolType.Tcp);

            server.Bind(new IPEndPoint(IPAddress.Any, 9050));

            server.Listen(10);

            Console.WriteLine("Server Started...");

            while (true)
            {
                Socket client = server.Accept();

                Console.WriteLine("Client Connected");

                Thread t = new Thread(() => HandleClient(client));
                t.Start();
            }
        }

        static void HandleClient(Socket client)
        {
            try
            {
                NetworkStream ns = new NetworkStream(client);

                StreamReader sr = new StreamReader(ns);
                StreamWriter sw = new StreamWriter(ns);

                // ============================
                // RECEIVE FILE SIZE
                // ============================

                int fileSize = int.Parse(sr.ReadLine());

                Console.WriteLine("File Size = " + fileSize);

                // ============================
                // RECEIVE FILE BYTES
                // ============================

                byte[] fileBytes = new byte[fileSize];

                int totalReceived = 0;

                while (totalReceived < fileSize)
                {
                    int received = ns.Read(
                        fileBytes,
                        totalReceived,
                        fileSize - totalReceived);

                    totalReceived += received;
                }

                // SAVE ORIGINAL FILE
                File.WriteAllBytes("received.txt", fileBytes);

                Console.WriteLine("File Received");

                // ============================
                // COMPRESS FILE
                // ============================

                FileStream originalFile =
                    new FileStream("received.txt", FileMode.Open);

                FileStream compressedFile =
                    new FileStream("compressed.gz", FileMode.Create);

                GZipStream gzip =
                    new GZipStream(compressedFile, CompressionMode.Compress);

                originalFile.CopyTo(gzip);

                gzip.Close();
                originalFile.Close();
                compressedFile.Close();

                Console.WriteLine("File Compressed");

                // ============================
                // SEND COMPRESSED FILE
                // ============================

                byte[] compressedBytes =
                    File.ReadAllBytes("compressed.gz");

                sw.WriteLine(compressedBytes.Length);
                sw.Flush();

                ns.Write(
                    compressedBytes,
                    0,
                    compressedBytes.Length);

                Console.WriteLine("Compressed File Sent");

                client.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}