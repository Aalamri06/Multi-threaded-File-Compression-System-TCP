﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System;
using System.IO;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Windows.Forms;

namespace ClientSite
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonBrowse_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();

            if (ofd.ShowDialog() == DialogResult.OK)
            {
                textBoxPath.Text = ofd.FileName;
            }
        }

        private void buttonSend_Click(object sender, EventArgs e)
        {
            try
            {
                // =========================
                // CONNECT TO SERVER
                // =========================

                Socket client = new Socket(
                    AddressFamily.InterNetwork,
                    SocketType.Stream,
                    ProtocolType.Tcp);

                client.Connect("127.0.0.1", 9050);

                richTextBox1.AppendText("Connected To Server\r\n");

                // =========================
                // NETWORK STREAMS
                // =========================

                NetworkStream ns = new NetworkStream(client);

                StreamReader sr = new StreamReader(ns);
                StreamWriter sw = new StreamWriter(ns);

                // =========================
                // READ FILE
                // =========================

                byte[] fileBytes =
                    File.ReadAllBytes(textBoxPath.Text);

                // =========================
                // SEND FILE SIZE
                // =========================

                sw.WriteLine(fileBytes.Length);
                sw.Flush();

                // =========================
                // SEND FILE BYTES
                // =========================

                ns.Write(fileBytes, 0, fileBytes.Length);

                richTextBox1.AppendText("File Sent\r\n");

                // =========================
                // RECEIVE COMPRESSED SIZE
                // =========================

                int compressedSize =
                    int.Parse(sr.ReadLine());

                richTextBox1.AppendText(
                    "Compressed Size = "
                    + compressedSize +
                    "\r\n");

                // =========================
                // RECEIVE COMPRESSED FILE
                // =========================

                byte[] compressedBytes =
                    new byte[compressedSize];

                int totalReceived = 0;

                while (totalReceived < compressedSize)
                {
                    int received = ns.Read(
                        compressedBytes,
                        totalReceived,
                        compressedSize - totalReceived);

                    totalReceived += received;
                }

                // =========================
                // SAVE FILE
                // =========================

                File.WriteAllBytes(
                    "compressed.gz",
                    compressedBytes);

                richTextBox1.AppendText(
                    "Compressed File Received\r\n");

                client.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
